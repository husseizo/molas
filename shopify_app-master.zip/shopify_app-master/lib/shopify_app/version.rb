# frozen_string_literal: true
module ShopifyApp
  VERSION = '18.0.2'
end
