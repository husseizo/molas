# frozen_string_literal: true
Rails.application.configure do
end
